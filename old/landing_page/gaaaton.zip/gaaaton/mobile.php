<?php
        $remarketing = '<!-- Google Code for &#1502;&#1512;&#1499;&#1494; &#1502;&#1489;&#1511;&#1512;&#1497;&#1501; Conversion Page -->
                        <script type="text/javascript">
                        /* <![CDATA[ */
                        var google_conversion_id = 961549092;
                        var google_conversion_language = "en";
                        var google_conversion_format = "3";
                        var google_conversion_color = "ffffff";
                        var google_conversion_label = "m0_xCITrwiUQpKbAygM";
                        var google_remarketing_only = false;
                        /* ]]> */
                        </script>
                        <script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
                        </script>
                        <noscript>
                        <div style="display:inline;">
                        <img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/961549092/?label=m0_xCITrwiUQpKbAygM&amp;guid=ON&amp;script=0"/>
                        </div>
                        </noscript>
                        ';        
?>
<!DOCTYPE HTML>
<html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>gaaton</title>
    
        
            <!--[if IE]>
                <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
            <![endif]-->
       
         <link type="text/css" rel="stylesheet" href="normalize.css"/>
        <style type="text/css">
         
                .clearfix:before,.clearfix:after {content:""; display:table;}
                .clearfix:after {clear:both;}
                .floatLeft { float:left;}
                .floatRight{float:right;}
                
                 a img { border:0 none; }
                 a {text-decoration:none;}
                    
            * {
                margin:0;
                padding:0;
                
            }
            article, aside, figure, footer, header, nav, section { display: block; }
            
            body {
                    direction:rtl;
                    text-decoration:none;
                    font-family:Arial, Helvetica, sans-serif;
                    font-size: 14px;
                    }
                 
			 
		#outerContact { 
				width:320px;
				height:480px;
				 margin:0 auto;
				position:relative;
				background-image: url(images/mob1back.png);
				background-repeat:no-repeat;
				  }
          
		
		#Name , #Email, #Phone  {  
					  width: 282px;
					  height: 29px;
					  -webkit-border-radius: 15px 14px 14px 15px/15px 15px 14px 14px;
					  -moz-border-radius: 15px 14px 14px 15px/15px 15px 14px 14px;
					  border-radius: 15px 14px 14px 15px/15px 15px 14px 14px;
					  background-color: #fff;
					  -webkit-box-shadow: inset 1px 2px 7px rgba(0,3,0,.75); 
					  -moz-box-shadow: inset 1px 2px 7px rgba(0,3,0,.75); 
					  box-shadow: inset 1px 2px 7px rgba(0,3,0,.75);
				      border: solid 1px #fff;
					  color:#9e9fa0;
					  padding-right:8px;
					  font-size:16px;
				   }     
				
	
			#Name {
					right: 16px;
				position: absolute;
				bottom:144px;
			}
	  
		  #Email{
			  position: absolute;
				right: 16px;
				bottom:102px;
			}
			
				
					
		#Phone {
			right: 16px;
			position: absolute;
			bottom:62px;
		}

	 
		#button {
			right:126px;
			position: absolute;
			bottom:8px;
			}

	
	  .submit-button {
				  width: 72px; height: 30px;
				 -webkit-border-radius: 19px/20px 20px 19px 19px; 
				 -moz-border-radius: 19px/20px 20px 19px 19px; 
				  border-radius: 19px/20px 20px 19px 19px;
				  background-color: #fff; 
				  border:1px solid  #fff;
				  color:#3e0f15;
				  font-size:16px;
				  font-weight:bold;
				 }

	
          img.main_pic  {
			  position:absolute;
			  left:0;
			  top:60px;
		    }
	
	
	         h2 { 
			  position:absolute;
			  right:0;
			  top:80px ;
			  width:159px;
			  text-align:center;
			  color:#fff;
			  }
	
	
			 ul.one  {
				position:absolute;
				top:207px;
				right:25px;
				width:282px;
			    list-style-type: square;
			  }
				
	  
			 li {
				  width:100%;
				 line-height:1.2em;
				 color:#fff;
			  }
		  
	
			 li a { 
				 width:100%;
				 padding-right:8px;
				 color:#fff;
				 font-size:12px;
				 line-height:0.8em;
			   }
	
/*	          
	
	           li:before { 
				content: "";
				border-color: transparent #111;
				border-style: solid;
				border-width: 0.35em 0 0.35em 0.35em;
				display: block;
				height: 0 em;
				width:  0.35em;
				left: 1em;
				top: 0.9em;
				position: relative;
              }
	*/
	         
	
	
	
	
	
	
	
	
			 h3 {
				  width: 100%; 
				  height: 27px; 
				  position: absolute;
				  top:117px ;
				 left:5px ;
				 color:#0b1a67;
				 text-align:center;
				}
			 
				 
				 p { 
				  width:100%;
				  position:absolute;
				  right:0;
				  bottom:130px ;
				  text-align:center;
				  color:#fff;
				  font-size:12px;
				  font-weight:bold;
				  } 
				  
			  
				 h1 { 
				 width:100%;
				 position:absolute;
				 right:0px;
				 top:-6px;
				 color:#fff;
				 font-size:1.8em;
				 font-weight:bold;
				 text-align:center;
			  }
			  
			  
			  
			  h2 { 
			  	 width:100%;
				 position:absolute;
				 right:0px;
				 top:180px;
				 color:#fff;
				 font-size:1.3em;
				 font-weight:bold;
				 text-align:center;
			    } 
				
				
					 
				 .video_button {
					 width:99px;
					 height:99px;
					 position:absolute;
					 top:81px;
					 right:126px;
				    } 
	
	    </style>
        
        

	</head>

	<body>
          <?php if($_GET['t']==1){ echo $remarketing;}?>
          <div id="outerContact">
                 
                <h1>ביקור במרכז המבקרים</h1>
                
                      <a class="video_button" href="#"> <img src="images/mob_video.png" width="63" height="62"></a>
                
                <h2>חייגו עכשיו 052-8698051</h2>
                            
                           <ul class="one">
                             
                                <li> <a href="#">ביקור במרכז אורך כשעה אחת.</a></li>
                                <li> <a href="#">לקבוצות וליחידים המבקרים באזור הגליל המערבי</a></li>
                                <li>  <a href="#">טעימת שיכרים מופלאים ועשרים בטעם</a></li>
                                <li> <a href="#">חוויה גלילית אמתית</a></li>

                            
                         </ul>   
                         
                         
               
                            <form method="post" action="send.php">
                             <input type="text" placeholder="שם מלא" name="Name" id="Name" />
                            <input type="email" placeholder="מייל "name="Email" id="Email" />
                            <input type="tel" placeholder="טלפון" name="Phone" id="Phone" />
                            <input type="hidden" name="next" value="mobile1.php?t=1"/>
                            <input type="hidden" name="to" value="dovbrav@gmail.com"/>
                            <input type="hidden" name="subject" value="מארז מיוחד לראש השנה"/>
                              <div id="button">  
                                  <input type="submit" name="submit" value="שלח" class="submit-button" />     
                             </div> <!--end midleForm-->
                    </form>  
          </div>

	</body>

</html>
